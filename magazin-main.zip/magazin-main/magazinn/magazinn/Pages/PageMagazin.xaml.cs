﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazinn.Pages;
using magazinn.Classes;


namespace magazinn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMagazin.xaml
    /// </summary>
    public partial class PageMagazin : Page
    {
        public PageMagazin()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.ToList();
            var listRro = MagazinEntities.GetContext().Company.Select(x => x.CompanyName).Distinct().ToList();
            CmbFiltrGroup.Items.Add("Все компании");
            foreach(string com in listRro)
            {
                CmbFiltrGroup.Items.Add(com);
            }


        }
        //private void btnEdit_Click(object sender, RoutedEventArgs e)
        ////Редактирование пользователей
        //{
        //    ClassFrame.frmObj.Navigate(new AddEditPagq((sender as Button).DataContext as Products));
        //}

        //private void BtnAdd_Click(object sender, RoutedEventArgs e)
        //// Добавление пользователей
        //{
        //    ClassFrame.frmObj.Navigate(new AddEditPagq(null)/*((Person)DGridUsers.SelectedItem)*/);
        //}

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких пользователей
            var personForRemoving = DGridUsers.SelectedItems.Cast<Products>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MagazinEntities.GetContext().Products.RemoveRange(personForRemoving);
                    MagazinEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                MagazinEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.ToList();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.ToList();
        }

        private void CmbFiltrGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int id = Convert.ToInt32(CmbFiltrGroup.SelectedValue);
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.Where(x => x.IDcompany == id).ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.OrderBy(x => x.Product).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.OrderByDescending(x => x.Product).ToList();
        }

       

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Products.Where(x => x.Product.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        //private void BtnToList_Click(object sender, RoutedEventArgs e)
        //{
        //    ClassFrame.frmObj.Navigate(new PageListStudent());
        //}
    }
}
